function App() {
  return <h1>Hello world!</h1>;
}

export default App;
