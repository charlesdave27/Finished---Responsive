export default function Page({ children }) {
  return <div>{children}</div>;
}
